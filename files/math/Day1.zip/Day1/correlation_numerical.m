clear; clc;

% --- 加载数据并处理缺失值 ---
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Age(ismissing(data.Age)) = median(data.Age, 'omitnan');
    data.Score(ismissing(data.Score)) = median(data.Score, 'omitnan');
    disp(['成功加载并处理缺失值后的数据: ', filename]);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% 提取数值列
age_data = data.Age;
score_data = data.Score;

disp('--- Pearson相关系数 ---');
% corr(X, Y) 计算X和Y之间的Pearson相关系数
% corr(X) 计算X中所有列之间的相关系数矩阵
pearson_corr = corr(age_data, score_data, 'Rows', 'complete'); % 'complete'忽略任何含有NaN的行
fprintf('Age和Score之间的Pearson相关系数: %.4f\n', pearson_corr);

% 计算多个数值变量的Pearson相关系数矩阵
numeric_vars = data(:, {'Age', 'Score'}); % 选择Age和Score列
pearson_corr_matrix = corr(numeric_vars{:, :}, 'Rows', 'complete');
disp('Age和Score的Pearson相关系数矩阵:');
disp(array2table(pearson_corr_matrix, 'VariableNames', numeric_vars.Properties.VariableNames, 'RowNames', numeric_vars.Properties.VariableNames));

disp('--- Spearman秩相关系数 ---');
spearman_corr = corr(age_data, score_data, 'Type', 'Spearman', 'Rows', 'complete');
fprintf('Age和Score之间的Spearman秩相关系数: %.4f\n', spearman_corr);

disp('--- Kendall秩相关系数 ---');
kendall_corr = corr(age_data, score_data, 'Type', 'Kendall', 'Rows', 'complete');
fprintf('Age和Score之间的Kendall秩相关系数: %.4f\n', kendall_corr);

% --- 可视化相关性 ---
figure;
scatter(age_data, score_data, 'filled');
title(['Age 与 Score 散点图 (Pearson r = ', num2str(pearson_corr, '%.2f'), ')']);
xlabel('年龄');
ylabel('分数');
grid on;