clear; clc;

% 加载示例数据
filename = 'sample_data.csv';
try
    data = readtable(filename);
    disp('成功加载示例数据:');
    disp(data);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% --- 点表示法 ---
% 使用点表示法访问Age列
age_column = data.Age;
disp('使用点表示法提取的Age列 (作为数值数组):');
disp(age_column);
disp(['age_column的数据类型是: ', class(age_column)]);

% --- 括号表示法 ---
% 选择前5行和'Age', 'City'两列，结果仍是table
sub_table = data(1:5, {'Age', 'City'});
disp('使用圆括号索引得到的子表格:');
disp(sub_table);
disp(['sub_table 的数据类型是: ', class(sub_table)]);

% 选择所有满足条件的行 (逻辑索引)
% 找出所有来自'Beijing'的记录
beijing_records = data(strcmp(data.City, 'Beijing'), :);
disp('所有来自北京的记录子表格:');
disp(beijing_records);

% --- 花括号表示法 ---
% 提取前5行的'Score'列数据，结果是数值数组
score_data_subset = data{1:5, 'Score'};
disp('使用花括号提取的前5行Score数据 (作为数值数组):');
disp(score_data_subset);
disp(['score_data_subset 的数据类型是: ', class(score_data_subset)]);