clear; clc;

% --- AHP权重计算与一致性检验函数 ---
function [W, CR] = ahp_weight(A)
    [n, ~] = size(A);
    RI = [0 0 0.58 0.90 1.12 1.24 1.32 1.41 1.45 1.49];
    [V, D] = eig(A);
    lambda_max = max(diag(D));
    [~, col] = find(D == lambda_max);
    W_unnormalized = V(:, col);
    W = W_unnormalized / sum(W_unnormalized);
    CI = (lambda_max - n) / (n - 1);
    CR = CI / RI(n);
end

% --- 主程序 ---
A = [1 2 4; 1/2 1 3; 1/4 1/3 1];
B1 = [1 2 4; 1/2 1 3; 1/4 1/3 1];
B2 = [1 1/3 1/5; 3 1 1/2; 5 2 1];
B3 = [1 3 5; 1/3 1 2; 1/5 1/2 1];
[W_A, CR_A] = ahp_weight(A);
[W_B1, CR_B1] = ahp_weight(B1);
[W_B2, CR_B2] = ahp_weight(B2);
[W_B3, CR_B3] = ahp_weight(B3);
fprintf('准则层判断矩阵的一致性比例 CR = %.4f\n', CR_A);
if CR_A < 0.1, disp('准则层通过一致性检验。'); else, disp('准则层未通过一致性检验！'); end
W_B = [W_B1, W_B2, W_B3];
final_score = W_B * W_A;
destinations = {'杭州', '厦门', '成都'};
results_table = table(destinations', final_score, 'VariableNames', {'Destination', 'Score'});
sorted_results = sortrows(results_table, 'Score', 'descend');
disp('--- AHP旅游目的地选择结果 ---');
disp(sorted_results);
fprintf('根据AHP分析，推荐的最佳旅游目的地是: %s\n', sorted_results.Destination{1});