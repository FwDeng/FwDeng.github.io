clear; clc;

% --- 加载数据并处理缺失值 ---
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Age(ismissing(data.Age)) = mean(data.Age, 'omitnan'); % 使用均值填充Age
    data.Score(ismissing(data.Score)) = median(data.Score, 'omitnan'); % 中位数填充Score
    disp(['成功加载并处理缺失值后的数据: ', filename]);
    disp(data);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% 提取需要处理的数值列
age_data = data.Age;
score_data = data.Score;

disp('--- Min-Max规范化 ---');
min_age = min(age_data);
max_age = max(age_data);
normalized_age = (age_data - min_age) / (max_age - min_age);

min_score = min(score_data);
max_score = max(score_data);
normalized_score = (score_data - min_score) / (max_score - min_score);

data.NormalizedAge_MinMax = normalized_age;
data.NormalizedScore_MinMax = normalized_score;
disp('Min-Max规范化后的数据预览 (Age和Score):');
disp(data(:, {'Age', 'NormalizedAge_MinMax', 'Score', 'NormalizedScore_MinMax'}));

% 检查范围
disp(['Min-Max Age范围: [', num2str(min(normalized_age)), ', ', num2str(max(normalized_age)), ']']);
disp(['Min-Max Score范围: [', num2str(min(normalized_score)), ', ', num2str(max(normalized_score)), ']']);

disp('--- Z-score标准化 ---');
% MATLAB的normalize函数可以直接进行Z-score标准化
standardized_age = normalize(age_data, 'zscore'); % 或normalize(age_data)，因为Z-score是默认方法
standardized_score = normalize(score_data, 'zscore'); % 或normalize(score_data)，因为Z-score是默认方法

data.StandardizedAge_Zscore = standardized_age;
data.StandardizedScore_Zscore = standardized_score;
disp('Z-score标准化后的数据预览 (Age和Score):');
disp(data(:, {'Age', 'StandardizedAge_Zscore', 'Score', 'StandardizedScore_Zscore'}));

% 检查均值和标准差
disp(['Z-score Age均值: ', num2str(mean(standardized_age)), ', 标准差: ', num2str(std(standardized_age))]);
disp(['Z-score Score均值: ', num2str(mean(standardized_score)), ', 标准差: ', num2str(std(standardized_score))]);