clear; clc;

% 加载数据
filename = 'sample_data.csv';
try
    data = readtable(filename);
    disp(['成功加载数据文件: ', filename]);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% 识别缺失值
disp('--- 识别缺失值 ---');
% 使用 ismissing 函数检测整个数据表中的缺失值
missing_mask = ismissing(data);
disp('缺失值掩码 (1表示缺失):');
disp(missing_mask);

% 统计每列的缺失值数量
num_missing_per_column = sum(missing_mask);
disp('每列的缺失值数量:');
disp(num_missing_per_column);

% 统计总缺失值数量
total_missing_values = sum(missing_mask(:));
disp(['总缺失值数量: ', num2str(total_missing_values)]);

% 找出包含缺失值的行
rows_with_missing = any(missing_mask, 2);
disp('包含缺失值的行索引:');
disp(find(rows_with_missing));

% 缺失值处理策略演示
% 策略1: 删除含有缺失值的行
disp('--- 策略1: 删除含有缺失值的行 ---');
data_deleted_rows = rmmissing(data);
disp('删除缺失值行后的数据预览:');
disp(data_deleted_rows);
disp(['原始行数: ', num2str(size(data, 1)), ', 删除后行数: ', num2str(size(data_deleted_rows, 1))]);

% 策略2: 使用均值填充Age列的缺失值
disp('--- 策略2: 使用均值填充Age列 ---');
data_mean_imputed = data; % 创建副本以避免修改原始数据
mean_age = nanmean(data_mean_imputed.Age); % 计算非缺失值的均值
data_mean_imputed.Age(ismissing(data_mean_imputed.Age)) = mean_age;
disp('均值填充Age列后的数据预览:');
disp(data_mean_imputed);
% 对于MATLAB R2016b及以上版本，可以直接使用fillmissing函数
% data_mean_imputed.Age = fillmissing(data.Age, 'constant', mean(data.Age, 'omitnan'));
% disp('均值填充Age列后的数据预览（直接使用fillmissing）:');
% disp(data_mean_imputed);

% 策略3: 使用中位数填充Score列的缺失值
disp('--- 策略3: 使用中位数填充Score列 ---');
data_median_imputed = data; % 创建副本
median_score = median(data_median_imputed.Score, 'omitnan'); % 计算非缺失值的中位数
data_median_imputed.Score(ismissing(data_median_imputed.Score)) = median_score;
disp('中位数填充 "Score" 列后的数据预览:');
disp(data_median_imputed);
% 对于MATLAB R2016b及以上版本，可以直接使用fillmissing函数
% data_median_imputed.Score = fillmissing(data.Score, 'constant', median(data.Score, 'omitnan'));
% disp('中位数填充Score列后的数据预览（直接使用fillmissing）:');
% disp(data_median_imputed);

% 策略4: 使用插值法填充Score列的缺失值 (适用于有序或时间序列数据)
% 假设Score存在某种趋势，这里使用线性插值
disp('--- 策略4: 使用线性插值填充Score列 ---');
data_interp_imputed = data; % 创建副本
% 对于表格列，需要先转换为数组进行插值，再赋值回表格
score_array = data_interp_imputed.Score;
missing_idx = ismissing(score_array);
% 找到非缺失值的索引和值
known_idx = find(~missing_idx);
known_values = score_array(known_idx);
% 对缺失值进行线性插值
interp_values = interp1(known_idx, known_values, find(missing_idx), 'linear', 'extrap');
data_interp_imputed.Score(missing_idx) = interp_values;
disp('线性插值填充Score列后的数据预览:');
disp(data_interp_imputed);
% 对于MATLAB R2016b及以上版本，可以直接使用fillmissing函数
% data_interp_imputed.Score = fillmissing(data.Score, 'linear');
% disp('线性插值填充Score列后的数据预览（直接使用fillmissing）:');
% disp(data_interp_imputed);