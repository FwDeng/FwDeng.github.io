clear; clc;

% --- 加载数据并处理缺失值 ---
% 为了描述性统计的准确性，通常需要先处理缺失值，这里我们使用中位数填充Age和Score列的缺失值
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Age(ismissing(data.Age)) = median(data.Age, 'omitnan');
    data.Score(ismissing(data.Score)) = median(data.Score, 'omitnan');
    disp('处理后的数据预览:');
    disp(data);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% 提取数值列
age_data = data.Age;
score_data = data.Score;

% 集中趋势度量
mean_age = mean(age_data);
median_age = median(age_data);
mode_age = mode(age_data);
fprintf('Age均值: %.2f\n', mean_age);
fprintf('Age中位数: %.2f\n', median_age);
fprintf('Age众数: %s\n', mat2str(mode_age)); % 可能返回多个众数

% 离散程度度量
var_age = var(age_data);
std_age = std(age_data);
range_age = range(age_data);
Q1_age = prctile(age_data, 25);
Q3_age = prctile(age_data, 75);
IQR_age = Q3_age - Q1_age;
fprintf('Age方差: %.2f\n', var_age);
fprintf('Age标准差: %.2f\n', std_age);
fprintf('Age极差: %.2f\n', range_age);
fprintf('Age Q1 (25th percentile): %.2f\n', Q1_age);
fprintf('Age Q3 (75th percentile): %.2f\n', Q3_age);
fprintf('Age IQR: %.2f\n', IQR_age);

% 分布形态度量
skew_age = skewness(age_data);
kurt_age = kurtosis(age_data);
fprintf('Age偏度: %.2f\n', skew_age);
fprintf('Age峰度: %.2f\n', kurt_age); % MATLAB的kurtosis函数返回的已经是超峰度 (kurtosis - 3)