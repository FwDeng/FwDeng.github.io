% 清除工作区和命令行
clear;
clc;

% 图像文件
filename_image = 'sample_image.png';

% 使用imread加载图像
try
    img_data = imread(filename_image);
    disp(['成功加载图像文件: ', filename_image]);
    disp('图像数据维度 (行 x 列 x 颜色通道):');
    disp(size(img_data)); % 显示图像的维度

    % 显示图像
    figure; % 创建一个新的图形窗口
    imshow(img_data); % 显示图像
    title('加载并显示的图像');
catch ME
    warning('加载图像文件失败。请确保文件已下载并位于当前工作目录。');
    disp(['错误信息: ', ME.message]);
end