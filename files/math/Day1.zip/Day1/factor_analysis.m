clear; clc;

% --- 生成模拟数据 ---
% 假设有两个潜在因子: 
% 因子1: 教学质量 (影响X1, X2, X3, X6)
% 因子2: 学业压力 (影响X4, X5)
base = rand(50, 2) * 5 + 3; % 50个样本，2个基础因子
noise = randn(50, 6) * 0.5; % 噪声

X = zeros(50, 6);
% 教学质量因子
X(:,1) = base(:,1) * 1.2 + noise(:,1); % 课程内容
X(:,2) = base(:,1) * 1.1 + noise(:,2); % 教师教学
X(:,3) = base(:,1) * 0.9 + noise(:,3); % 教材质量
X(:,6) = base(:,1) * 1.3 + noise(:,6); % 学习收获
% 学业压力因子
X(:,4) = base(:,2) * 1.1 + noise(:,4); % 作业难度
X(:,5) = base(:,2) * 1.0 + noise(:,5); % 考核方式

% 数据约束在1-10分
X(X>10) = 10;
X(X<1) = 1;
X = round(X, 1);

% --- 执行因子分析 ---
% 使用'factoran'函数；假设我们想提取2个因子
num_factors = 2;
% 'rotate', 'varimax' 是最常用的旋转方法
[Loadings, ~, ~, ~, stats] = factoran(X, num_factors, 'rotate', 'varimax');

disp('--- 因子分析结果 ---');
disp('因子载荷矩阵 (旋转后):');
varNames = {'课程内容','教师教学','教材质量','作业难度','考核方式','学习收获'};
LoadingsTable = array2table(Loadings, 'RowNames', varNames, 'VariableNames', {'Factor1', 'Factor2'});
disp(LoadingsTable);

disp(' ');
disp('解读:');
disp('因子1在“课程内容”、“教师教学”、“教材质量”、“学习收获”上有高载荷，可解释为“教学质量因子”。');
disp('因子2在“作业难度”、“考核方式”上有高载荷，可解释为“学业压力因子”。');

% --- 可视化因子载荷 ---
figure;
biplot(Loadings, 'varlabels', varNames);
title('因子载荷图');
xlabel('因子1 (教学质量)');
ylabel('因子2 (学业压力)');
grid on;