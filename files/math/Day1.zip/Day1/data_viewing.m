clear; clc;

% 加载示例数据 (沿用之前的CSV数据) 
filename_csv = 'sample_data.csv';
try
    data_table = readtable(filename_csv);
    disp(['成功加载CSV文件: ', filename_csv]);
catch ME
    error('加载CSV文件失败。');
end

disp(' ');

% 查看工作区变量信息：whos命令显示当前工作区中所有变量的名称、大小、字节数和数据类型
disp('工作区变量信息：');
whos data_table; % 只查看data_table变量的信息

disp(' ');

% 查看数据表的大小：size函数返回数据表的行数和列数
[numRows, numCols] = size(data_table);
disp(['行数 (观测值数量): ', num2str(numRows)]);
disp(['列数 (变量数量): ', num2str(numCols)]);

disp(' ');

% 查看数据表的前几行和后几行：head和tail函数分别显示数据表的前几行和后几行（默认前8行）
disp('数据表前5行：');
disp(head(data_table, 5));

disp(' ');

disp('数据表后5行：');
disp(tail(data_table, 5));

disp(' ');

% 获取数据表的变量名称：data_table.Properties.VariableNames返回一个包含所有列名的单元格数组
disp('数据表各列列名：');
disp(data_table.Properties.VariableNames);

disp(' ');

% 获取数据表的摘要统计信息：summary函数为数据表中的每个变量提供摘要统计信息，包括数据类型、缺失值数量、均值、中位数、最小值、最大值等
disp('数据表摘要统计信息 (summary) ：');
summary(data_table);