clear; clc;

% 创建包含异常值的示例数据
% 假设我们有一个身高数据，其中包含一些录入错误或极端值
heights = [165, 170, 172, 168, 175, 180, 173, 171, 169, 195, 150, 174, 160, 177, 176, 200, 140];
data_table_outlier = table(heights', 'VariableNames', {'Height'});
disp('原始数据预览 (包含异常值):');
disp(data_table_outlier);

disp('--- 用Z-score法进行异常值识别 ---');
mu = mean(data_table_outlier.Height);
sigma = std(data_table_outlier.Height);
z_scores = (data_table_outlier.Height - mu) / sigma;
threshold_z = 2.5; % 通常取2到3之间
is_outlier_zscore = abs(z_scores) > threshold_z;
disp(['Z-score阈值: ', num2str(threshold_z)]);
disp('Z-score法识别的异常值索引:');
disp(find(is_outlier_zscore));
disp('Z-score法识别的异常值:');
disp(data_table_outlier.Height(is_outlier_zscore));

disp('--- 用IQR倍数法进行异常值识别 ---');
Q1 = prctile(data_table_outlier.Height, 25); % 第1四分位数
Q3 = prctile(data_table_outlier.Height, 75); % 第3四分位数
IQR = Q3 - Q1;
lower_bound = Q1 - 1.5 * IQR;
upper_bound = Q3 + 1.5 * IQR;

is_outlier_iqr = (data_table_outlier.Height < lower_bound) | (data_table_outlier.Height > upper_bound);
disp(['IQR下界: ', num2str(lower_bound)]);
disp(['IQR上界: ', num2str(upper_bound)]);
disp('IQR倍数法识别的异常值索引:');
disp(find(is_outlier_iqr));
disp('IQR倍数法识别的异常值:');
disp(data_table_outlier.Height(is_outlier_iqr));

disp('--- 策略1: 删除异常值 (使用IQR倍数法识别的结果) ---');
data_deleted_outliers = data_table_outlier(~is_outlier_iqr, :);
disp('删除异常值后的数据预览:');
disp(data_deleted_outliers);
disp(['原始行数: ', num2str(size(data_table_outlier, 1)), ', 删除后行数: ', num2str(size(data_deleted_outliers, 1))]);

disp('--- 策略2: 替换异常值 (用中位数替换) ---');
data_imputed_outliers = data_table_outlier; % 创建副本
median_height = median(data_table_outlier.Height(~is_outlier_iqr)); % 计算非异常值的中位数
data_imputed_outliers.Height(is_outlier_iqr) = median_height;
disp('中位数替换异常值后的数据预览:');
disp(data_imputed_outliers);

disp('--- 策略3: 截断异常值 (用IQR边界值替换) ---');
data_truncated_outliers = data_table_outlier; % 创建副本
data_truncated_outliers.Height(data_truncated_outliers.Height < lower_bound) = lower_bound;
data_truncated_outliers.Height(data_truncated_outliers.Height > upper_bound) = upper_bound;
disp('截断异常值后的数据预览:');
disp(data_truncated_outliers);