clear; clc;

% --- 加载数据 ---
filename = 'sample_excel_data.xlsx';
try
    data = readtable(filename);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

data.Date = datetime(data.Date); % 确保Date列是datetime类型

disp('--- 从日期中提取特征 ---');
data.Year = year(data.Date); % 年份
data.Month = month(data.Date); % 月份
data.Day = day(data.Date); % 日期
data.DayOfWeek = weekday(data.Date); % 星期几 (1=星期日, 7=星期六)
data.IsWeekend = (data.DayOfWeek == 1 | data.DayOfWeek == 7); % 是否周末 (逻辑值)

disp('提取日期特征后的数据预览:');
disp(data);

disp('--- 组合特征 (销售额与产品类型的交互) ---');
% 假设我们想知道不同产品在不同销售额区间的表现
% 可以先对销售额进行分箱，然后与产品类型结合
num_sales_bins = 3;
binned_sales = discretize(data.Sales, num_sales_bins, 'categorical');
data.SalesBin = binned_sales;

% 创建一个表示产品和销售额区间的组合特征
data.ProductSalesInteraction = strcat(string(data.Product), '_', string(data.SalesBin));
disp('组合特征后的数据预览:');
disp(data(:, {'Product', 'Sales', 'SalesBin', 'ProductSalesInteraction'}));

disp('--- 聚合特征 (按产品类型计算平均销售额) ---');
% 使用groupsummary函数按Product分组计算平均销售额
avg_sales_by_product = groupsummary(data, 'Product', 'mean', 'Sales');
disp('按产品类型聚合的平均销售额:');
disp(avg_sales_by_product);

% 将聚合结果合并回原始数据 (如果需要作为新特征)
% 注意：这需要使用join函数，确保CustomerID或Product是Key
% 假设我们想把每个订单所属产品的平均销售额作为新特征加到原始数据中
data_with_avg_sales = join(data, avg_sales_by_product, 'Keys', 'Product');
% 重命名新加入的列
data_with_avg_sales = renamevars(data_with_avg_sales, 'mean_Sales', 'AvgSalesPerProduct');
disp('添加聚合特征后的数据预览:');
disp(head(data_with_avg_sales));