clear; clc;

% --- 加载数据并处理缺失值 ---
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Age(ismissing(data.Age)) = median(data.Age, 'omitnan');
    data.Score(ismissing(data.Score)) = median(data.Score, 'omitnan');
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% 将Gender和City转换为categorical类型，便于绘图
data.Gender = categorical(data.Gender);
data.City = categorical(data.City);

figure('Name', '数值型变量可视化', 'NumberTitle', 'off');

% Age的直方图
subplot(2, 3, 1);
histogram(data.Age);
title('Age 直方图');
xlabel('年龄');
ylabel('频数');
grid on;

% Age的密度图
subplot(2, 3, 2);
ksdensity(data.Age); % 核密度估计
title('Age 密度图');
xlabel('年龄');
ylabel('概率密度');
grid on;

% Age的箱线图
subplot(2, 3, 3);
boxplot(data.Age);
title('Age 箱线图');
ylabel('年龄');
grid on;

% Score的直方图
subplot(2, 3, 4);
histogram(data.Score);
title('Score 直方图');
xlabel('分数');
ylabel('频数');
grid on;

% Score的密度图
subplot(2, 3, 5);
ksdensity(data.Score);
title('Score 密度图');
xlabel('分数');
ylabel('概率密度');
grid on;

% Score的箱线图
subplot(2, 3, 6);
boxplot(data.Score);
title('Score 箱线图');
ylabel('分数');
grid on;

sgtitle('数值型变量单变量可视化'); % 总标题