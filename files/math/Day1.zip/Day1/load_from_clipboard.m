clear; clc;

% 从剪贴板获取文本数据
% 请在运行此代码前，手动复制一些表格数据（例如从Excel复制）到剪贴板
pause(5); % 暂停5秒，给用户复制数据的时间
clipboard_content = clipboard('paste');
disp('从剪贴板获取到的内容:');
disp(clipboard_content);

% 将剪贴板内容尝试转换为表格
temp_filename = 'temp_clipboard_data.csv';
try
    fid = fopen(temp_filename, 'w'); % 以写入模式打开临时文件
    fprintf(fid, '%s', clipboard_content); % 将剪贴板内容写入文件
    fclose(fid); % 关闭文件

    % 使用readtable读取临时文件
    clipboard_table = readtable(temp_filename);
    disp('从剪贴板内容转换得到的表格数据:');
    disp(clipboard_table);

    % 清理临时文件
    delete(temp_filename);
catch ME
    warning('无法将剪贴板内容转换为表格。请确保剪贴板内容是有效的表格数据。');
    disp(['错误信息: ', ME.message]);
    % 转换失败，尝试删除临时文件
    if exist(temp_filename, 'file')
        delete(temp_filename);
    end
end