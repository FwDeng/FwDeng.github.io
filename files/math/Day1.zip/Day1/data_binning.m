clear; clc;

% --- 加载数据并处理缺失值 ---
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Score(ismissing(data.Score)) = nanmedian(data.Score); % 填充缺失值，以便进行分箱
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end
score_data = data.Score;

disp('--- 等宽分箱 ---');
num_bins_equal_width = 4; % 分为4个箱子
% discretize函数可以方便地进行分箱
% 第一个参数是数据，第二个参数是箱子边界或箱子数量
% 'categorical'选项将结果作为分类数组返回
binned_score_equal_width = discretize(score_data, num_bins_equal_width, 'categorical');
data.BinnedScore_EqualWidth = binned_score_equal_width;
disp(['等宽分箱 (', num2str(num_bins_equal_width), '个箱子) 后的数据预览:']);
disp(data(:, {'Score', 'BinnedScore_EqualWidth'}));

% 查看每个箱子的计数
disp('等宽分箱后每个箱子的计数:');
disp(groupcounts(data, 'BinnedScore_EqualWidth'));

disp('--- 等频分箱 ---');
num_bins_equal_freq = 4; % 分为4个箱子
edges = quantile(score_data, linspace(0, 1, num_bins_equal_freq+1)); % 计算分位点作为边界
binned_score_equal_freq = discretize(score_data, edges, 'IncludedEdge', 'right');
data.BinnedScore_EqualFreq = binned_score_equal_freq;
disp(['等频分箱 (', num2str(num_bins_equal_freq), '个箱子) 后的数据预览:']);
disp(data(:, {'Score', 'BinnedScore_EqualFreq'}));

% 查看每个箱子的计数
disp('等频分箱后每个箱子的计数:');
disp(groupcounts(data, 'BinnedScore_EqualFreq'));