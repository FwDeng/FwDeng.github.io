clear; clc;

filename_customers = 'customers.csv';
filename_orders = 'orders.csv';

try
    customers_data = readtable(filename_customers);
    orders_data = readtable(filename_orders);
    disp('成功加载客户数据:');
    disp(customers_data);
    disp('成功加载订单数据:');
    disp(orders_data);
catch ME
    error(['加载文件失败。请确保 ', filename_customers, ' 和 ', filename_orders, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

% inner join (内连接): 只保留两个表中共同存在的 CustomerID 对应的记录
disp('--- 使用inner join合并数据，基于CustomerID字段 ---');
merged_inner = innerjoin(customers_data, orders_data, 'Keys', 'CustomerID');
disp('Inner Join结果:');
disp(merged_inner);
% 注意：C005的订单由于在customers_data中不存在，被丢弃