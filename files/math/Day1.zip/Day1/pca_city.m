clear; clc;

% --- 数据准备 ---
X = [20000 45000 18000 12000 2500;
     25000 58000 23000 10000 2000;
     22000 65000 10000 9000  1800;
     18000 58000 17000 7500  2200;
     15000 52000 13000 6000  1800;
     12000 48000 11000 5000  1500;
      9000 52000 18000 3500  1100;
      7000 38000  6500 2800   900;
      5000 32000  4500 4000   600;
      3000 48000  8500 8200   400];
city_names = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J'};
indicator_names = {'GDP', '人均收入', '工业产值', '消费总额', '财政收入'};

% --- 使用内置函数pca进行分析 ---
% coeff: 主成分系数 (特征向量)
% score: 主成分得分
% latent: 特征值
% explained: 各主成分的方差贡献率
[coeff, score, latent, ~, explained] = pca(X);

disp('--- 主成分分析结果 ---');
fprintf('各主成分的方差贡献率 (%%):\n');
disp(explained');

cumulative_explained = cumsum(explained);
fprintf('累计方差贡献率 (%%):\n');
disp(cumulative_explained');

% 确定需要的主成分数量 (例如累计贡献率>90%)
num_components = find(cumulative_explained >= 90, 1, 'first');
fprintf('\n选择前 %d 个主成分，其累计贡献率为 %.2f%%。\n', num_components, cumulative_explained(num_components));

% 查看主成分系数 (载荷)
disp('主成分载荷矩阵 (Coefficients):');
disp(coeff);
fprintf('\n例如，第一主成分 F1 = %.4f*X1 + %.4f*X2 + ...\n', coeff(1,1), coeff(2,1));
disp('载荷的绝对值大小反映了原始变量对主成分的贡献程度。');

% --- 计算综合得分并排名 ---
% 使用方差贡献率作为权重，对选定的主成分得分进行加权求和
weights = explained(1:num_components) / sum(explained(1:num_components));
final_score = score(:, 1:num_components) * weights;

% 将结果整理成表格
results_table = table(city_names', final_score, 'VariableNames', {'城市', '综合经济得分'});
% 按得分降序排序
sorted_results = sortrows(results_table, '综合经济得分', 'descend');
disp('城市综合经济实力排名:');
disp(sorted_results);

% 用碎石图进行可视化，用于辅助判断主成分数量
figure;
pareto(explained);
title('主成分分析碎石图 (Scree Plot)');
xlabel('主成分');
ylabel('方差贡献率 (%)');

% 绘制主成分得分图 (前两个主成分)
figure;
scatter(score(:,1), score(:,2), 'filled');
% 为每个点添加城市标签
text(score(:,1)+0.2, score(:,2), city_names);
xlabel('第一主成分 (F1 - 综合规模)');
ylabel('第二主成分 (F2)');
title('城市在主成分空间的分布');
grid on;
ax = gca;
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';