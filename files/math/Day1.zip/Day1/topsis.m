clear; clc;

% --- 数据准备 ---
X = [10.5 98.5 15;
     12.0 99.2 12;
     11.2 97.8 10;
     10.8 98.8 18];
W = [0.4, 0.3, 0.3];
indicator_type = [-1, 1, -1];
supplier_names = {'S1', 'S2', 'S3', 'S4'};
[m, n] = size(X);

% --- 数据正向化 ---
X_pos = X;
for j = 1:n
    if indicator_type(j) == -1
        X_pos(:, j) = 1 ./ X(:, j);
    end
end

% --- 标准化 ---
Z = X_pos ./ sqrt(sum(X_pos.^2));

% --- 计算加权标准化矩阵 ---
V = Z .* W;

% --- 确定正负理想解 ---
V_plus = max(V);
V_minus = min(V);

% --- 计算距离 ---
D_plus = sqrt(sum((V - V_plus).^2, 2));
D_minus = sqrt(sum((V - V_minus).^2, 2));

% --- 计算相对贴近度 ---
C = D_minus ./ (D_plus + D_minus);

% --- 结果展示 ---
results_table = table(supplier_names', C, 'VariableNames', {'Supplier', 'Score'});
sorted_results = sortrows(results_table, 'Score', 'descend');
disp('--- TOPSIS供应商评价结果 ---');
disp(sorted_results);
fprintf('根据TOPSIS分析，最佳供应商是: %s\n', sorted_results.Supplier{1});