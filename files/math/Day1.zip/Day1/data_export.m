clear; clc;

% 准备一份简单的数据
ID = (1:5)';
Age = [25; 30; 22; 28; 35];
City = {'Beijing'; 'Shanghai'; 'Guangzhou'; 'Beijing'; 'Shanghai'};
Score = [85; 92; 78; 88; 95];
cleaned_data = table(ID, Age, City, Score);

disp('准备导出的数据表:');
disp(cleaned_data);

% 定义要保存的文件名
output_filename_excel = 'final_report.xlsx';

% 使用writetable导出到Excel
try
    % 默认写入名为'Sheet1'的工作表
    writetable(cleaned_data, output_filename_excel);
    disp(['数据已成功导出到: ', output_filename_excel, ' (默认工作表)']);

    % 导出到指定的工作表（可指定Sheet名称）
    sheet_name = 'CleanedData';
    writetable(cleaned_data, output_filename_excel, 'Sheet', sheet_name);
    disp(['数据已成功导出到工作表: ', sheet_name]);
catch ME
    disp(['错误信息: ', ME.message]);
end