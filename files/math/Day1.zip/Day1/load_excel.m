% 清除工作区和命令行
clear;
clc;

% 加载Excel文件
filename_excel = 'sample_excel_data.xlsx';

% 使用readtable加载文件
% 默认加载第一个工作表，可以指定工作表名称或索引
try
    data_table_excel = readtable(filename_excel);
    disp(['成功加载Excel文件: ', filename_excel]);
    disp('数据表预览 (所有行):');
    disp(data_table_excel); % 显示整个数据表
catch ME
    warning('加载Excel文件失败。请确保文件已下载并位于当前工作目录。');
    disp(['错误信息: ', ME.message]);
end

% 加载指定工作表
% 如果Excel文件有多个工作表，可以指定加载特定的工作表
% 例如，加载名为'Sheet2'的工作表
% data_sheet2 = readtable(filename_excel, 'Sheet', 'Sheet2');
% disp('加载Sheet2的数据表预览:');
% disp(data_sheet2);

% 旧版函数
% xlsread可以用来读取Excel数据，但它返回的是数值矩阵、文本单元格数组和原始数据单元格数组，不如readtable方便
% [num, txt, raw] = xlsread(filename_excel);
% disp('使用xlsread加载的数值数据:');
% disp(num);
% disp('使用xlsread加载的文本数据:');
% disp(txt);