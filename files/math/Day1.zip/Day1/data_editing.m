clear; clc;

% 加载示例数据
filename = 'sample_data.csv';
data = readtable(filename);

% --- 添加新列 ---
% 例如，我们根据分数给出一个'Level'等级
% 假设分数>=90为'Excellent', >=80为'Good', 其他为'Fair'
data.Level = repmat({''}, height(data), 1); % 先创建一个空的cell列
data.Level(data.Score >= 90) = {'Excellent'};
data.Level(data.Score >= 80 & data.Score < 90) = {'Good'};
data.Level(data.Score < 80) = {'Fair'};
data.Level = categorical(data.Level); % 转换为分类类型更佳
disp('添加Level列后的表格:');
disp(data);

% --- 删除列 ---
% 将ID列赋值为空矩阵[]即可删除该列
data.ID = [];
disp('删除ID列后的表格:');
disp(data);

% --- 重命名列 ---
% 使用 renamevars 函数重命名列
data = renamevars(data, "Score", "FinalScore");
disp('重命名列后的表格:');
disp(data);

% --- 修改单元格数据 ---
% 直接使用索引进行赋值
data.Age(1) = 26; % 将第一行的Age修改为26
data{3, 'City'} = {'Tianjin'}; % 将第三行的城市修改为'Tianjin'
disp('修改单元格数据后的表格:');
disp(data);