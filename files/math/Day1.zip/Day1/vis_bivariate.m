 clear; clc;

% --- 加载数据并处理缺失值 ---
filename_data = 'sample_data.csv';
filename_excel = 'sample_excel_data.xlsx';

try
    data_sample = readtable(filename_data);
    data_sample.Age(ismissing(data_sample.Age)) = median(data_sample.Age, 'omitnan');
    data_sample.Score(ismissing(data_sample.Score)) = median(data_sample.Score, 'omitnan');
    data_sample.Gender = categorical(data_sample.Gender); % 转换为分类类型

    data_excel = readtable(filename_excel);
    data_excel.Date = datetime(data_excel.Date); % 确保日期是datetime类型
    disp(['成功加载数据文件: ', filename_excel]);

catch ME
    error(['加载文件失败。请确保所有示例文件已下载并位于当前工作目录。错误: ', ME.message]);
end

figure('Name', '双变量可视化', 'NumberTitle', 'off');

% 散点图（Age vs Score）
subplot(2, 2, 1);
scatter(data_sample.Age, data_sample.Score, 'filled'); % 'filled'使点实心
title('年龄与分数散点图');
xlabel('年龄');
ylabel('分数');
grid on;

% 按性别分组的散点图
subplot(2, 2, 2);
gscatter(data_sample.Age, data_sample.Score, data_sample.Gender, [], 'ox', 8); % 按 Gender 分组绘制散点图
title('年龄与分数散点图 (按性别)');
xlabel('年龄');
ylabel('分数');
legend('Location', 'best');
grid on;

% 折线图 (时间序列数据: Sales vs Date)
subplot(2, 2, 3);
plot(data_excel.Date, data_excel.Sales, '-o');
title('每日销售额趋势');
xlabel('日期');
ylabel('销售额');
datetick('x', 'yyyy-mm-dd'); % 格式化X轴日期显示
grid on;

% 分组箱线图 (数值型 vs 分类型: Score by Gender)
subplot(2, 2, 4);
boxplot(data_sample.Score, data_sample.Gender);
title('按性别划分的分数分布');
xlabel('性别');
ylabel('分数');
grid on;

sgtitle('双变量可视化示例'); % 总标题