clear; clc;

sales_jan = table({'P001';'P002'}, [100;120], 'VariableNames', {'ProductID', 'Sales'});
sales_feb = table({'P002';'P003'}, [150;90], 'VariableNames', {'ProductID', 'Sales'});
disp('数据表sales_jan:');
disp(sales_jan)
disp('数据表sales_feb:');
disp(sales_feb)
disp('--- 垂直拼接示例 ---');
all_sales = vertcat(sales_jan, sales_feb);
disp('垂直拼接结果:');
disp(all_sales);

student_scores = table({'S001';'S002';'S003'}, [85;92;78], 'VariableNames', {'StudentID', 'MathScore'});
student_physical = table({'S001';'S002';'S003'}, [170;165;175], 'VariableNames', {'StudentID', 'Height'});
disp('数据表student_scores:');
disp(student_scores)
disp('数据表student_physical:');
disp(student_physical)
disp('--- 水平拼接示例 ---');
% horzcat要求行数相同且顺序一致（否则应使用join的方法），这里假设顺序一致
combined_student_data = horzcat(student_scores, student_physical(:, 'Height')); % 只取Height列
disp('水平拼接结果:');
disp(combined_student_data);