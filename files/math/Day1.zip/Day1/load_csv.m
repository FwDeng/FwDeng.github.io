% 清除工作区和命令行
clear;
clc;

% 加载CSV文件
filename_csv = 'sample_data.csv';

% 使用readtable加载文件
try
    data_table_csv = readtable(filename_csv);
    disp(['成功加载CSV文件: ', filename_csv]);
    disp('数据表预览 (前5行):');
    disp(head(data_table_csv, 5)); % 显示数据表的前5行
catch ME
    warning('加载CSV文件失败。请确保文件已下载并位于当前工作目录。');
    disp(['错误信息: ', ME.message]);
end

% 更多选项
% 如果CSV文件没有列名，或者分隔符不是逗号，可以添加更多选项
% 如果文件没有标题行
% data_no_header = readtable(filename_csv, 'ReadVariableNames', false);

% 如果文件使用分号作为分隔符
% data_semicolon_delimited = readtable('data_semicolon.csv', 'Delimiter', ';');