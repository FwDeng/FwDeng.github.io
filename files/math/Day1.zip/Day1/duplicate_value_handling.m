clear; clc;

% 创建包含重复值的示例数据
% 假设有一个客户订单数据，可能存在重复录入
data_raw = {
    'A001', 'ProductX', 100, '2024-01-01';
    'A002', 'ProductY', 150, '2024-01-02';
    'A001', 'ProductX', 100, '2024-01-01'; % 重复行
    'A003', 'ProductZ', 200, '2024-01-03';
    'A002', 'ProductY', 150, '2024-01-02'; % 重复行
    'A004', 'ProductX', 120, '2024-01-04';
    'A001', 'ProductX', 100, '2024-01-01'; % 再次重复
};
data_table_duplicate = cell2table(data_raw, 'VariableNames', {'OrderID', 'Product', 'Amount', 'OrderDate'});
disp('原始数据预览 (包含重复值):');
disp(data_table_duplicate);

disp('--- 识别重复行 ---');
% 使用unique函数
[~, unique_indices] = unique(data_table_duplicate, 'rows', 'stable'); % unique_indices是唯一行的索引
is_duplicate = true(size(data_table_duplicate, 1), 1); % 默认所有行都是重复的
is_duplicate(unique_indices) = false; % 将唯一行标记为非重复

disp('重复行索引:');
disp(find(is_duplicate));
disp('重复行数据:');
disp(data_table_duplicate(is_duplicate, :));

disp('--- 删除重复行 ---');
data_no_duplicates = unique(data_table_duplicate, 'rows', 'stable');
disp('删除重复行后的数据预览:');
disp(data_no_duplicates);
disp(['原始行数: ', num2str(size(data_table_duplicate, 1)), ', 删除后行数: ', num2str(size(data_no_duplicates, 1))]);