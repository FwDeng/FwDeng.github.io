clear; clc;

% --- 加载数据 ---
filename = 'sample_data.csv';
try
    data = readtable(filename);
    data.Gender = categorical(data.Gender);
    data.City = categorical(data.City);
    disp(['成功加载数据文件: ', filename]);
catch ME
    error(['加载文件失败。请确保 ', filename, ' 已下载并位于当前工作目录。错误: ', ME.message]);
end

disp('--- 交叉表 (Gender vs City) ---');
% 可直接使用crosstab函数
[contingency_table, chi2, p, labels] = crosstab(data.Gender, data.City);
disp('性别与城市交叉表:');
disp(array2table(contingency_table, 'VariableNames', labels(:,2)', 'RowNames', labels(1:2,1)'));

disp('--- 卡方检验结果 ---');
fprintf('卡方统计量 (Chi-square statistic): %.4f\n', chi2);
fprintf('P值 (p-value): %.4f\n', p);

% 判断关联性
alpha = 0.05; % 显著性水平
if p < alpha
    disp(['P值 (', num2str(p), ') 小于显著性水平 (', num2str(alpha), ')，拒绝原假设。']);
    disp('结论: 性别与城市之间存在显著关联。');
else
    disp(['P值 (', num2str(p), ') 大于显著性水平 (', num2str(alpha), ')，不拒绝原假设。']);
    disp('结论: 性别与城市之间没有显著关联。');
end

% 计算 Cramer's V
num_observations = height(data);
num_rows_table = size(contingency_table, 1);
num_cols_table = size(contingency_table, 2);
cramers_v_denominator = num_observations * min(num_rows_table - 1, num_cols_table - 1);
if cramers_v_denominator > 0
    cramers_v = sqrt(chi2 / cramers_v_denominator);
    fprintf('Cramer''s V: %.4f\n', cramers_v);
else
    disp('无法计算 Cramer''s V (分母为零)。');
end

% --- 可视化交叉表 (堆叠条形图) ---
figure;
bar(contingency_table, 'stacked');
title('性别与城市分布 (堆叠条形图)');
xlabel('性别');
ylabel('人数');
legend(labels(:,2), 'Location', 'bestoutside'); % 城市作为图例
xticks(1:num_rows_table);
xticklabels(labels(:,1)); % 性别作为X轴标签
grid on;