clear; clc;

% --- 数据准备 (使用与TOPSIS案例相同的原始数据) ---
X = [10.5 98.5 15;
     12.0 99.2 12;
     11.2 97.8 10;
     10.8 98.8 18];
[m, n] = size(X);

% --- 数据标准化 (Min-Max Normalization) ---
indicator_type = [-1, 1, -1];
X_norm = zeros(m, n);
for j = 1:n
    min_val = min(X(:, j));
    max_val = max(X(:, j));
    if indicator_type(j) == 1 % Benefit
        X_norm(:, j) = (X(:, j) - min_val) / (max_val - min_val);
    else % Cost
        X_norm(:, j) = (max_val - X(:, j)) / (max_val - min_val);
    end
end
X_norm = X_norm + 1e-6; % 防止出现0

% --- 计算信息熵 ---
P = X_norm ./ sum(X_norm);
k = 1 / log(m);
E = -k * sum(P .* log(P));

% --- 计算权重 ---
D = 1 - E;
W_entropy = D / sum(D);

disp('--- 熵权法计算的指标权重 ---');
fprintf('价格(X1)权重: %.4f\n', W_entropy(1));
fprintf('质量(X2)权重: %.4f\n', W_entropy(2));
fprintf('供货周期(X3)权重: %.4f\n', W_entropy(3));
disp('可以将此权重W_entropy代入上面的TOPSIS模型中进行客观评价。');