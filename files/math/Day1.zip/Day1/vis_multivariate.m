clear; clc;

filename_data = 'sample_data.csv';
filename_excel = 'sample_excel_data.xlsx';

try
    data_sample = readtable(filename_data);
    % 填充缺失值
    data_sample.Age(ismissing(data_sample.Age)) = median(data_sample.Age, 'omitnan');
    data_sample.Score(ismissing(data_sample.Score)) = median(data_sample.Score, 'omitnan');

    data_excel = readtable(filename_excel);
    % 为了演示多变量可视化，我们尝试合并一些数值列，假设我们只关心数值数据，并取部分数据进行合并演示
    combined_numeric_data = table();
    combined_numeric_data.Age = data_sample.Age(1:min(height(data_sample), height(data_excel)));
    combined_numeric_data.Score = data_sample.Score(1:min(height(data_sample), height(data_excel)));
    combined_numeric_data.Sales = data_excel.Sales(1:min(height(data_sample), height(data_excel)));
    
    disp('用于多变量可视化的合并数值数据预览:');
    disp(combined_numeric_data);

catch ME
    error(['加载或准备数据失败。请确保所有示例文件已下载并位于当前工作目录。错误: ', ME.message]);
end

figure('Name', '多变量可视化', 'NumberTitle', 'off');

% 散点图矩阵
subplot(1, 2, 1); % 分割图窗为1行2列，当前在第1个
plotmatrix(combined_numeric_data{:, :}); % 对所有数值列绘制散点图矩阵
title('数值变量散点图矩阵');

% 相关系数热力图
subplot(1, 2, 2); % 当前在第2个
variable_names = combined_numeric_data.Properties.VariableNames;
correlation_matrix = corr(combined_numeric_data{:, :}, 'Rows', 'complete'); % 计算相关系数矩阵，忽略NaN
heatmap(variable_names, variable_names, correlation_matrix);
title('数值变量相关系数热力图');
colormap(jet); % 设置颜色映射
colorbar; % 显示颜色条

sgtitle('多变量可视化示例'); % 总标题