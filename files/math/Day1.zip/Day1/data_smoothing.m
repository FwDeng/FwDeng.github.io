clear; clc;

% --- 模拟包含随机噪声的时间序列数据 ---
time_points = (1:50)'; % 50个时间点
true_sales = 100 + 0.5 * time_points + 5 * sin(time_points/5); % 真实趋势
noise = 10 * randn(size(time_points)); % 随机噪声
observed_sales = true_sales + noise; % 观测到的销售数据

data_time_series = table(time_points, observed_sales, 'VariableNames', {'Time', 'Sales'});
disp('原始时间序列数据预览 (前5行):');
disp(head(data_time_series));

disp('--- 移动平均 ---');
% 使用 movmean 函数进行移动平均平滑
% 窗口大小为5，即计算当前点前后各2个点以及当前点共5个点的平均值
% 'omitnan'选项用于处理NaN值，尽管这里数据没有NaN，但建议保留以避免出现问题
window_size = 5;
smoothed_sales = movmean(data_time_series.Sales, window_size, 'omitnan');
data_time_series.SmoothedSales = smoothed_sales;

disp('平滑后的数据预览 (包含原始和平滑销售额):');
disp(head(data_time_series));

% 可视化平滑效果
figure;
plot(data_time_series.Time, data_time_series.Sales, 'b-o', 'DisplayName', '原始销售额', 'MarkerSize', 3);
hold on;
plot(data_time_series.Time, data_time_series.SmoothedSales, 'r-', 'LineWidth', 2, 'DisplayName', '移动平均平滑销售额');
plot(data_time_series.Time, true_sales, 'g--', 'DisplayName', '真实趋势', 'LineWidth', 1.5);
hold off;
title(['销售数据平滑 (移动平均, 窗口大小 = ', num2str(window_size), ')']);
xlabel('时间');
ylabel('销售额');
legend('Location', 'northwest');
grid on;