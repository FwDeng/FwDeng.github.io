clear; clc;

% 创建有冲突的示例数据
% 表A: 包含客户ID和年龄，ID列名为'Client_ID'
data_A = table({'C001';'C002';'C003'}, [25;30;22], 'VariableNames', {'Client_ID', 'Age'});
disp('数据表A:');
disp(data_A);

% 表B: 包含客户ID和性别，ID列名为'CustomerID'，且性别为数值编码
data_B = table({'C001';'C002';'C004'}, [1;0;1], 'VariableNames', {'CustomerID', 'Gender_Code'}); % 1=Male, 0=Female
disp('数据表B:');
disp(data_B);

disp('--- 解决命名不一致冲突 ---');
% 将data_A中的'Client_ID'重命名为'CustomerID'以便合并
data_A_renamed = renamevars(data_A, 'Client_ID', 'CustomerID');
disp('数据表A重命名后:');
disp(data_A_renamed);

disp('--- 解决数据类型不一致冲突 ---');
% 将data_B中的'Gender_Code'转换为分类文本
data_B_converted = data_B; % 创建副本
data_B_converted.Gender_Code = categorical(data_B_converted.Gender_Code, [1, 0], {'Male', 'Female'});
disp('数据表B类型转换后:');
disp(data_B_converted);

disp('--- 合并解决冲突后的数据 ---');
merged_resolved = innerjoin(data_A_renamed, data_B_converted, 'Keys', 'CustomerID');
disp('合并后的数据:');
disp(merged_resolved);