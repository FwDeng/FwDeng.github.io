clear; clc;

% 加载示例数据
filename = 'sample_data.csv';
data = readtable(filename);

% --- groupcounts ---

% 按City分组计数
city_counts = groupcounts(data, 'City');
disp('按City分组的计数结果:');
disp(city_counts);

% 按City和Gender两个变量同时分组计数
multi_counts = groupcounts(data, {'City', 'Gender'});
disp('按City和Gender联合分组的计数结果:');
disp(multi_counts);

% --- groupsummary ---

% 为了演示，我们先填充缺失值
data.Age(ismissing(data.Age)) = mean(data.Age, 'omitnan');
data.Score(ismissing(data.Score)) = mean(data.Score, 'omitnan');

% --- 按单个变量分组，计算单个统计量 ---
% 计算每个城市的平均分数
mean_score_by_city = groupsummary(data, 'City', 'mean', 'Score');
disp('按City分组计算的平均分数:');
disp(mean_score_by_city);

% --- 按单个变量分组，计算多个统计量 ---
% 计算每个性别的人的平均年龄和分数标准差
stats_by_gender = groupsummary(data, 'Gender', {'mean', 'std'}, {'Age', 'Score'});
disp('按Gender分组计算的年龄均值和分数标准差:');
disp(stats_by_gender);