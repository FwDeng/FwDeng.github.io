clear; clc;

% 加载示例数据
filename = 'sample_data.csv';
data = readtable(filename);

% --- 按单列排序 ---
% 按Age列降序排序
sorted_by_age_desc = sortrows(data, 'Age', 'descend');
disp('按Age降序排序后的表格:');
disp(sorted_by_age_desc);

% --- 按多列排序 ---
% 先按City升序，如果City相同，则按Score降序
sorted_multi = sortrows(data, {'City', 'Score'}, {'ascend', 'descend'});
disp('按City(升序)和Score(降序)排序后的表格:');
disp(sorted_multi);